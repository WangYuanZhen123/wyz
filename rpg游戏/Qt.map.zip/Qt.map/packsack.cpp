#include "packsack.h"
#include "equipment.h"

/*Packsack::Packsack()
{
    equip1.setEquipment("Basic_equipment");
    equip2.setEquipment("Attract_equipment");
    equip3.setEquipment("Protective_equipment");
}*/

void Packsack::initPacksack()
{
    this->equip1.initObj("equip1");
    this->equip1.setPosX(500);
    this->equip1.setPosY(120);
    this->equip2.initObj("equip2");
    this->equip2.setPosX(500);
    this->equip2.setPosY(100);
    this->equip3.initObj("equip3");
    this->equip3.setPosX(460);
    this->equip3.setPosY(120);

    //image01.load("D:\\QT_work\\QT_assignment\\Qt.map\\equipment\\01.png");
    //image02.load("D:\\QT_work\\QT_assignment\\Qt.map\\equipment\\02.png");
    //image03.load("D:\\QT_work\\QT_assignment\\Qt.map\\equipment\\03.png");


}

/*void Packsack::showback(QPainter *painter)
{
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++)
    {
        (*it).show(painter);
    }
}*/

void Packsack::show(QPainter *painter)
{
    if(Flag==1)         this->equip1.show(painter);
    else if(Flag==2)    this->equip2.show(painter);
    else if(Flag==3)    this->equip3.show(painter);
}

int Packsack::getProperty(int num, QString str)
{
    if(num==1)
    {
        equip1.getData(str);
    }
    else if(num==2)
    {
        equip2.getData(str);
    }
    else if(num==3)
    {
        equip3.getData(str);
    }
}
