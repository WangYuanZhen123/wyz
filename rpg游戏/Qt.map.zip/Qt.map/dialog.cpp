#include "dialog.h"
#include <QPainter>
#include "packsack.h"
#include "equipment.h"
#include "ui_myqdialog.h"
#include "fightworld.h"
#include <QMovie>
#include <QTImer>
#include <QCursor>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    setWindowTitle("");
    display=0;
    who = 0;
    got=3;
    skill=0;
    skill0=0;
    enemy1 = true;
    enemy2 = true;
    enemy3 = true;

    QCursor *myCursor=new QCursor(QPixmap("C:\\Users\\67549\\Desktop\\5690530967350055f\\more\\cursor.png"),-1,-1);
    this->setCursor(*myCursor);

    _bag.initPacksack();
    fightworld.initWorld();

    blood0.load("C:\\Users\\67549\\Desktop\\Qt.map\\blood11.png");
    blood1.load("C:\\Users\\67549\\Desktop\\Qt.map\\blood22.png");
    victory.load("C:\\Users\\67549\\Desktop\\Qt.map\\victory.png");
    lose.load("C:\\Users\\67549\\Desktop\\Qt.map\\lose.png");

    movie0= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\00.gif");
    movie11= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\11.gif");
    movie12= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\12.gif");
    movie13= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\13.gif");
    movie21= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\21.gif");
    movie31= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\31.gif");
    movie51= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\51.gif");
    movie52= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\52.gif");
    movie110= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\110.gif");
    movie120= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\120.gif");
    movie130= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\130.gif");
    movie210= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\210.gif");
    movie310= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\310.gif");
    movie510= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\510.gif");
    movie520= new QMovie("C:\\Users\\67549\\Desktop\\Qt.map\\PK\\520.gif");

    time = new QTimer(this);    //反击
    connect(time,SIGNAL(timeout()),this,SLOT(fanji()));
    time11 = new QTimer(this);         //停止主角技能
    connect(time11,SIGNAL(timeout()),this,SLOT(stop11()));   //timeoutslot()为自定义槽
    time22 = new QTimer(this);      //停止敌人技能
    connect(time22,SIGNAL(timeout()),this,SLOT(stop22()));   //timeoutslot()为自定义槽


    skill1 = new MyPushbutton(this);
    skill1->setGeometry(500,450,200,100);
    skill1->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang2.png");
    skill1->setText("星光引爆");
    skill1->setFont(QFont("宋体",10,QFont::Bold));
    QObject::connect(skill1,SIGNAL(clicked()),this,SLOT(skill10()));
    skill1->setVisible(false);

    skill2 = new MyPushbutton(this);
    skill2->setGeometry(500,500,200,100);
    skill2->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang2.png");
    skill2->setText("飞龙在天");
    skill2->setFont(QFont("宋体",10,QFont::Bold));
    QObject::connect(skill2,SIGNAL(clicked()),this,SLOT(skill20()));
    skill2->setVisible(false);

    skill3 = new MyPushbutton(this);
    skill3->setGeometry(500,550,200,100);
    skill3->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang2.png");
    skill3->setText("闪电风暴");
    skill3->setFont(QFont("宋体",10,QFont::Bold));
    QObject::connect(skill3,SIGNAL(clicked()),this,SLOT(skill30()));
    skill3->setVisible(false);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::paintEvent(QPaintEvent *)
{
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    if(display==0)      //装备界面
    {
        skill1->setVisible(false);
        skill2->setVisible(false);
        skill3->setVisible(false);
        pa->drawPixmap(rect(),QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\10.png"));
        pa->drawImage(QRect (160,170,140,180),QImage ("C:\\Users\\67549\\Desktop\\5690530967350055f\\NPC_1\\04\\image 1.png"),QRect (0,0,69,90));

        _bag.show(pa);
        this->setLabel();
        this->setPicture();

    }
    else if(display==1)        //战斗场景
    {

        ui->pushButton->hide();
        ui->label_5->hide();
        ui->label_6->hide();
        ui->label_7->hide();
        ui->label_8->hide();
        ui->pushButton_2->hide();
        pa->drawPixmap(rect(),QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\map3.jpg"));
 //       pa->drawImage(300,500,actor1);
  //      pa->drawImage(100,500,actor2);
        if(who==0)
        {
            int xue110;
            xue110=fightworld.evil1.getblood();        //得到角色血量
            xue110=xue110/100;
            if(xue110<=0)
                xue110=0;
            int xue120;
            xue120=fightworld.evil14.getblood();
            xue120=xue120/100;
            if(xue120<=0)
                xue120=0;
            int xue130;
            xue130=fightworld.evil15.getblood();
            xue130=xue130/100;
            if(xue130<=0)
                xue130=0;
            int xue210;
            xue210=fightworld.actor1.getblood();
            xue210=xue210/100;
            if(xue210<=0)
                xue210=0;

            pa->drawImage(QRect (280,450,160,50),blood0,QRect (0,0,200,50));  //绘制血量条
            pa->drawImage(QRect (440-16*(10-xue210),450,16*(10-xue210),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,350,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,350,32*(5-xue120),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (1080,450,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (1080,450,16*(10-xue110),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,550,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,550,32*(5-xue130),50),blood1,QRect (0,0,200,50));

            if(xue110<=0)
            {
                fightworld.evil1.changelive(false);
            }
            if(xue120<=0)
            {
                fightworld.evil14.changelive(false);
            }
            if(xue130<=0)
            {
                fightworld.evil15.changelive(false);
            }
            if(xue210<=0)
            {
                fightworld.actor1.changelive(false);
            }

            fightworld.show1(pa);
            if(fightworld.evil1.getlive()==false)
            {
                pa->drawImage(600,100,victory);
                enemy1 = false;
                fightworld.actor1.changeblood(2000);      //胜利后升级改变角色属性
            }
            else if(fightworld.actor1.getlive()==false)
            {
                pa->drawImage(700,100,lose);
                fightworld.actor1.changeblood(1000);        //失败后重置角色血量等属性
                fightworld.actor1.changelive(true);
                fightworld.evil1.changeblood(1000);
                fightworld.evil2.changelive(true);
                fightworld.evil14.changeblood(500);
                fightworld.evil21.changelive(true);
                fightworld.evil15.changeblood(500);
                fightworld.evil22.changelive(true);
            }

        }
        else if(who==1)
        {
            int xue11;
            xue11=fightworld.evil2.getblood();
            xue11=xue11/100;
            if(xue11<=0)
                xue11=0;
            int xue12;
            xue12=fightworld.evil21.getblood();
            xue12=xue12/100;
            if(xue12<=0)
                xue12=0;
            int xue13;
            xue13=fightworld.evil22.getblood();
            xue13=xue13/100;
            if(xue13<=0)
                xue13=0;
            int xue21;
            xue21=fightworld.actor1.getblood();
            xue21=xue21/100;
            if(xue21<=0)
                xue21=0;
            pa->drawImage(QRect (280,450,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (440-8*(20-xue21),450,8*(20-xue21),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,350,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,350,16*(10-xue12),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (1080,450,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (1080,450,8*(20-xue11),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,550,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (1180,550,16*(10-xue13),50),blood1,QRect (0,0,200,50));

            if(xue11<=0)
            {
                fightworld.evil2.changelive(false);
            }
            if(xue12<=0)
            {
                fightworld.evil21.changelive(false);
            }
            if(xue13<=0)
            {
                fightworld.evil22.changelive(false);
            }
            if(xue21<=0)
            {
                fightworld.actor1.changelive(false);
            }

            fightworld.show2(pa);
            if(fightworld.evil2.getlive()==false)
            {
                pa->drawImage(600,100,victory);
                enemy2 = false;
                fightworld.actor1.changeblood(4000);
                fightworld.actor1.changeattract(200);
            }
            else if(fightworld.actor1.getlive()==false)
            {
                pa->drawImage(700,100,lose);
                fightworld.actor1.changeblood(2000);
                fightworld.actor1.changelive(true);
                fightworld.evil2.changeblood(2000);
                fightworld.evil2.changelive(true);
                fightworld.evil21.changeblood(1000);
                fightworld.evil21.changelive(true);
                fightworld.evil22.changeblood(1000);
                fightworld.evil22.changelive(true);
            }

        }
        else if(who==2)
        {
            int xue11;
            xue11=fightworld.evil3.getblood();
            xue11=xue11/100;
            if(xue11<=0)
                xue11=0;
            int xue21;
            xue21=fightworld.actor1.getblood();
            xue21=xue21/100;
            if(xue21<=0)
                xue21=0;
            pa->drawImage(QRect (280,450,160,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (440-4*(40-xue21),450,4*(40-xue21),50),blood1,QRect (0,0,200,50));
            pa->drawImage(QRect (620,30,1000,50),blood0,QRect (0,0,200,50));
            pa->drawImage(QRect (620,30,25*(40-xue11),50),blood1,QRect (0,0,200,50));
            if(xue11<=0)
            {
                fightworld.evil3.changelive(false);
            }
            if(xue21<=0)
            {
                fightworld.actor1.changelive(false);
            }

            fightworld.show3(pa);
            if(fightworld.evil3.getlive()==false)
            {
                pa->drawImage(600,100,victory);
                enemy3 = false;
            }
            else if(fightworld.actor1.getlive()==false)
            {
                pa->drawImage(700,100,lose);
                fightworld.actor1.changeblood(4000);
                fightworld.actor1.changelive(true);
                fightworld.evil3.changeblood(4000);
            }

        }
    }
    pa->end();
    delete pa;
}


void Dialog::on_pushButton_clicked()
{
    int i;
    i=_bag.getFlag();
    i--;
    if(i>=1)    _bag.setFlag(i);
    else _bag.setFlag(1);
    this->repaint();
}

void Dialog::on_pushButton_2_clicked()
{
    int i;
    i=_bag.getFlag();
    i++;
    if(i<=3)    _bag.setFlag(i);
    else _bag.setFlag(3);
    this->repaint();
}

void Dialog::skill10()
{
    skill1->setVisible(false);
    skill2->setVisible(false);
    skill3->setVisible(false);
    ui->label->setGeometry(1080,330,350,350);
    ui->label->setMovie(movie11);
    movie11->start();
    ui->label_3->setGeometry(250,150,300,200);
    ui->label_3->setMovie(movie110);
    movie110->start();
    skill=1;
    ui->label->show();
    ui->label_3->show();
    time11->setSingleShot(true);
    time11->start();
    time11->setInterval(1600);
    if(who==0)
    {
        this->fightworld.evil1.changeblood(fightworld.evil1.getblood()-fightworld.actor1.getattract());
        this->fightworld.evil14.changeblood(fightworld.evil14.getblood()-fightworld.actor1.getattract());
        this->fightworld.evil15.changeblood(fightworld.evil15.getblood()-fightworld.actor1.getattract());
    }
    if(who==1)
    {
        this->fightworld.evil2.changeblood(fightworld.evil2.getblood()-fightworld.actor1.getattract());
        this->fightworld.evil21.changeblood(fightworld.evil21.getblood()-fightworld.actor1.getattract());
        this->fightworld.evil22.changeblood(fightworld.evil22.getblood()-fightworld.actor1.getattract());
    }
    if(who==2)
    {
        this->fightworld.evil3.changeblood(fightworld.evil3.getblood()-fightworld.actor1.getattract());
    }
    this->repaint();
}

void Dialog::skill20()
{
    skill1->setVisible(false);
    skill2->setVisible(false);
    skill3->setVisible(false);
    ui->label->setGeometry(1080,360,350,350);
    ui->label->setMovie(movie12);
    movie12->start();
    ui->label_3->setGeometry(250,150,300,200);
    ui->label_3->setMovie(movie120);
    movie120->start();
    skill=2;
    ui->label->show();
    ui->label_3->show();
    time11->setSingleShot(true);
    time11->start();
    time11->setInterval(3400);
    if(who==0)
    {
        this->fightworld.evil1.changeblood(fightworld.evil1.getblood()-fightworld.actor1.getattract()*2);
        this->fightworld.evil14.changeblood(fightworld.evil14.getblood()-fightworld.actor1.getattract()*2);
        this->fightworld.evil15.changeblood(fightworld.evil15.getblood()-fightworld.actor1.getattract()*2);
    }
    if(who==1)
    {
        this->fightworld.evil2.changeblood(fightworld.evil2.getblood()-fightworld.actor1.getattract()*2);
        this->fightworld.evil21.changeblood(fightworld.evil21.getblood()-fightworld.actor1.getattract()*2);
        this->fightworld.evil22.changeblood(fightworld.evil22.getblood()-fightworld.actor1.getattract()*2);
    }
    if(who==2)
    {
        this->fightworld.evil3.changeblood(fightworld.evil3.getblood()-fightworld.actor1.getattract()*2);
    }
    this->repaint();
}

void Dialog::skill30()
{
    skill1->setVisible(false);
    skill2->setVisible(false);
    skill3->setVisible(false);
    ui->label->setGeometry(1080,260,350,350);
    ui->label->setMovie(movie13);
    movie13->start();
    ui->label_3->setGeometry(250,150,300,200);
    ui->label_3->setMovie(movie130);
    movie130->start();
    skill=3;
    ui->label->show();
    ui->label_3->show();
    time11->setSingleShot(true);
    time11->start();
    time11->setInterval(4000);
    if(who==0)
    {
        this->fightworld.evil1.changeblood(fightworld.evil1.getblood()-fightworld.actor1.getattract()*3);
        this->fightworld.evil14.changeblood(fightworld.evil14.getblood()-fightworld.actor1.getattract()*3);
        this->fightworld.evil15.changeblood(fightworld.evil15.getblood()-fightworld.actor1.getattract()*3);
    }
    if(who==1)
    {
        this->fightworld.evil2.changeblood(fightworld.evil2.getblood()-fightworld.actor1.getattract()*3);
        this->fightworld.evil21.changeblood(fightworld.evil21.getblood()-fightworld.actor1.getattract()*3);
        this->fightworld.evil22.changeblood(fightworld.evil22.getblood()-fightworld.actor1.getattract()*3);
    }
    if(who==2)
    {
        this->fightworld.evil3.changeblood(fightworld.evil3.getblood()-fightworld.actor1.getattract()*3);
    }
    this->repaint();
}

void Dialog::setLabel()
{
    //int t,i,j;
    //t=_bag.getFlag();
    //i=_bag.getProperty(t,"Lethality");
    //j=_bag.getProperty(t,"Defense");
    ui->label_8->setText(tr("Lethality:1000\n Defense:1000\n"));
}
void Dialog::setPicture()
{    if(got==1)
        ui->label_5->setPixmap(QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\1.png"));
    else if(got==2)
    {
        ui->label_5->setPixmap(QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\1.png"));
        ui->label_6->setPixmap(QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\2.png"));
    }
    else
    {
        ui->label_5->setPixmap(QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\1.png"));
        ui->label_6->setPixmap(QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\2.png"));
        ui->label_7->setPixmap(QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\equipment\\3.png"));
    }
}


void Dialog::stop11()
{

    if(skill==1)        //判断在放的是哪个动图
    {
        movie11->stop();
        movie110->stop();
    }
    if(skill==2)
    {
        movie12->stop();
        movie120->stop();
    }
    if(skill==3)
    {
        movie13->stop();
        movie130->stop();
    }
    ui->label->hide();
    ui->label_3->hide();
    time->setSingleShot(true);
    time->start();
    time->setInterval(2000);
}

void Dialog::stop22()
{
    skill1->setVisible(true);
    skill2->setVisible(true);
    skill3->setVisible(true);
    if(skill0==1)
    {
        movie0->stop();

    }
    if(skill0==2)
    {
        movie21->stop();
        movie210->stop();
    }
    if(skill0==3)
    {
        movie31->stop();
        movie310->stop();
    }
    if(skill0==4)
    {
        movie51->stop();
        movie510->stop();
    }
    if(skill0==5)
    {
        movie52->stop();
        movie520->stop();
    }
    ui->label_2->hide();
    ui->label_4->hide();
}
void Dialog::fanji()
{

    ui->label_2->setGeometry(300,500,400,250);
    ui->label_4->setGeometry(1100,150,300,200);
    if(who==0)
    {
        if(fightworld.evil1.getblood()<=0)
            return;
        int k=0;
        if(fightworld.evil1.getblood()<800&&fightworld.evil1.getblood()>300)
        {
            if (2!=rand()%4)        //设置随机数来决定释放技能的几率
            {
                ui->label_2->setMovie(movie21);
                movie21->start();
                ui->label_2->show();
                ui->label_4->setMovie(movie210);
                movie210->start();
                ui->label_4->show();
                skill0=2;
                time22->setSingleShot(true);        //时间控制技能的释放时间
                time22->start();
                time22->setInterval(2200);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-2*fightworld.evil1.getattract());
                k=1;
            }
        }
        else if(fightworld.evil1.getblood()<=300)
        {
            if (4!=rand()%5)
            {
                ui->label_2->setMovie(movie21);
                movie21->start();
                skill0=2;
                ui->label_2->show();
                ui->label_4->setMovie(movie210);
                movie210->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2200);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-3*fightworld.evil1.getattract());
                k=1;
            }
        }
        if(k==0)    //如果没有释放技能，则用普通攻击
        {
            ui->label_2->setMovie(movie0);
            movie0->start();
            skill0=1;
            ui->label_2->show();
            time22->setSingleShot(true);
            time22->start();
            time22->setInterval(1600);
            this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-fightworld.evil1.getattract());
        }
    }
    if(who==1)
    {
        if(fightworld.evil2.getblood()<=0)
            return;
        int k=0;
        if(fightworld.evil2.getblood()<1500&&fightworld.evil2.getblood()>1000)
        {
            if (2!=rand()%4)
            {
                ui->label_2->setMovie(movie31);
                movie31->start();
                skill0=3;
                ui->label_2->show();
                ui->label_4->setMovie(movie310);
                movie310->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2600);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-2*fightworld.evil2.getattract());
                k=1;
            }
        }
        else if(fightworld.evil2.getblood()<=1000&&fightworld.evil2.getblood()>500)
        {
            if (2!=rand()%3)
            {
                ui->label_2->setMovie(movie31);
                movie31->start();
                skill0=3;
                ui->label_2->show();
                ui->label_4->setMovie(movie310);
                movie310->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2600);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-2*fightworld.evil2.getattract());
                k=1;
            }
        }
        else if(fightworld.evil2.getblood()<=500)
        {
            if (2!=rand()%3)
            {
                ui->label_2->setMovie(movie31);
                movie31->start();
                skill0=3;
                ui->label_2->show();
                ui->label_4->setMovie(movie310);
                movie310->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2600);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-3*fightworld.evil2.getattract());
                k=1;
            }
        }
        if(k==0)
        {
            ui->label_2->setMovie(movie0);
            movie0->start();
            skill0=0;
            ui->label_2->show();
            time22->setSingleShot(true);
            time22->start();
            time22->setInterval(1600);
            this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-fightworld.evil2.getattract());
        }
    }
    if(who==2)
    {
        if(fightworld.evil3.getblood()<=0)
            return;
        int k=0;
        if(fightworld.evil3.getblood()<3000&&fightworld.evil3.getblood()>2000)
        {
            if (2!=rand()%4)
            {
                ui->label_2->setMovie(movie51);
                movie51->start();
                skill0=4;
                ui->label_2->show();
                ui->label_4->setMovie(movie510);
                movie510->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2400);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-2*fightworld.evil3.getattract());
                k=1;
            }
        }
        else if(fightworld.evil2.getblood()<=2000&&fightworld.evil2.getblood()>1000)
        {
            if (2!=rand()%3)
            {
                ui->label_2->setMovie(movie51);
                movie51->start();
                skill0=4;
                ui->label_2->show();
                ui->label_4->setMovie(movie510);
                movie510->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2400);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-2*fightworld.evil3.getattract());
                k=1;
            }
            if (2!=rand()%3&&k==0)
            {
                ui->label_2->setMovie(movie52);
                movie52->start();
                skill0=5;
                ui->label_2->show();
                ui->label_4->setMovie(movie520);
                movie520->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2800);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-3*fightworld.evil3.getattract());
                k=1;
            }
        }
        else if(fightworld.evil2.getblood()<=1000)
        {
            if (1!=rand()%2)
            {
                ui->label_2->setMovie(movie51);
                movie51->start();
                skill0=4;
                ui->label_2->show();
                ui->label_4->setMovie(movie510);
                movie510->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2400);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-2*fightworld.evil3.getattract());
                k=1;
            }
            if (2!=rand()%3&&k==0)
            {
                ui->label_2->setMovie(movie52);
                movie52->start();
                skill0=5;
                ui->label_2->show();
                ui->label_4->setMovie(movie520);
                movie520->start();
                ui->label_4->show();
                time22->setSingleShot(true);
                time22->start();
                time22->setInterval(2800);
                this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-3*fightworld.evil3.getattract());
                k=1;
            }
        }
        if(k==0)
        {
            ui->label_2->setMovie(movie0);
            movie0->start();
            skill0=1;
            ui->label_2->show();
            time22->setSingleShot(true);
            time22->start();
            time22->setInterval(1600);
            this->fightworld.actor1.changeblood(fightworld.actor1.getblood()-fightworld.evil3.getattract());
        }
    }

    this->repaint();
}

