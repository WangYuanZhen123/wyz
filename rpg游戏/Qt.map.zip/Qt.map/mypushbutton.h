#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H
#include <QPushButton>

class MyPushbutton:public QPushButton
{
    Q_OBJECT
public:
    explicit MyPushbutton(QWidget *parent = 0);
       ~MyPushbutton();
       void getIconPath(QString icon_path);//寰楀埌鍥剧墖鐨勮矾寰勫悕瀛楋紝骞朵笖璁剧疆鎸夐挳涓哄浘鐗囩殑澶у皬
       void enterEvent(QEvent *);//杩涘叆浜嬩欢
       void leaveEvent(QEvent *);//绂诲紑浜嬩欢
       void mousePressEvent(QMouseEvent *event);  //榧犳爣鎸変笅浜嬩欢
       void mouseReleaseEvent(QMouseEvent *event); //榧犳爣閲婃斁浜嬩欢
       void paintEvent(QPaintEvent *);//鎸夐挳缁樺浘浜嬩欢

    private:
       enum ButtonStatus{NORMAL, HOVER, PRESS}; //鏋氫妇鎸夐挳鐨勫嚑绉嶇姸鎬?
       ButtonStatus status;
       QString icon_path;//璺緞鍚?
       bool mouse_press; //鎸夐挳宸﹂敭鏄惁鎸変笅
};

#endif // MYPUSHBUTTON_H
