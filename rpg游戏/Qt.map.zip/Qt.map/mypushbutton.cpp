#include "mypushbutton.h"
#include <QMouseEvent>
#include <QPainter>

MyPushbutton::MyPushbutton(QWidget *parent)
    :QPushButton(parent)
{
    status = NORMAL;
    mouse_press = false;
}
MyPushbutton::~MyPushbutton()
{
}
void MyPushbutton::getIconPath(QString Icon_path)
{
    this->icon_path = Icon_path;
    setFixedSize(QPixmap(Icon_path).size());//璁剧疆鎸夐挳涓庡浘鐗囦竴鏍风殑澶у皬
}

void MyPushbutton::enterEvent(QEvent *)
{
    status = HOVER;
    update();
}
void MyPushbutton::mousePressEvent(QMouseEvent *event)
{
    //鑻ョ偣鍑婚紶鏍囧乏閿?
    if(event->button() == Qt::LeftButton)
    {
        mouse_press = true;
        status = PRESS;
        update();
    }
}
void MyPushbutton::mouseReleaseEvent(QMouseEvent *event)
{
    //鑻ョ偣鍑婚紶鏍囧乏閿搷搴?
    if(mouse_press&&this->rect().contains(event->pos()))
    {
        mouse_press = false;
        status = HOVER;
        update();
        emit clicked();
    }
}
void MyPushbutton::leaveEvent(QEvent *)
{
    status = NORMAL;
    update();
}
void MyPushbutton::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pixmap;
    switch(status)
    {
    case NORMAL:
        {
            pixmap.load(icon_path);
            break;
        }
    case HOVER:
        {
            pixmap.load("C:\\Users\\67549\\Desktop\\Qt.map\\kuang1.png");
            break;
        }
    case PRESS:
        {
            pixmap.load(icon_path /*+ QString("_press")*/);
            break;
        }
    default:
            pixmap.load(icon_path);
    }
        painter.drawPixmap(rect(), pixmap);
        painter.drawText(this->rect(), Qt::AlignCenter, this->text());
}
