#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"


class World : public Player
{
    friend class MW1;
    friend class Talk;
public:
    World(){}
    ~World(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void showback(QPainter * painter);
        //游戏世界里的背景
    void show(QPainter *painter);
        //现实游戏世界里的角色
    void showfight(QPainter *painter);
        //怪物界面
    void handlePlayerMove1(int direction, int steps);
        //假定只有一个玩家
    int get_x(){return _player.getPosX();}
    int get_y(){return _player.getPosY();}

    void changeenemy11(bool m){enemy11=m;}
    void changeenemy22(bool m){enemy22=m;}
    void changeenemy33(bool m){enemy33=m;}


private:
    vector<RPGObj> _objs;
    RPGObj door;
    Player _player;   //主角
    Player npc1, npc2, npc3;
    Player enemy1, enemy2, enemy3;
    bool enemy11, enemy22, enemy33;       //判断怪物是否存活
    QImage image, image11, image12, image21, image22, image31, image32, image41, image42;  //人物走动图


};

#endif // WORLD_H
