#ifndef MYQDIALOG_H
#define MYQDIALOG_H
#include<QDialog>

namespace Ui {
class MyQDialog;
}
class MyQDialog : public QDialog
{
    Q_OBJECT
public:
    explicit MyQDialog(QWidget *parent=0);
    ~MyQDialog();
   void paintEvent(QPaintEvent *);
   /*
signals:

public slots:
    void slotOpenNewWindow();*/

private:
   Ui::MyQDialog *ui2;

};

#endif // MYQDIALOG_H
