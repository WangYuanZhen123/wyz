#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <QTimer>
#include <cmath>
#include <map>
#include <iostream>
#include <QPixmap>
#include <QCursor>
#include "dialog.h"
#include <fstream>
#include <QtMultimedia/QMediaPlayer>
#include <QUrl>

using namespace std;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);
    dlg = new Dialog(this);
    //init game world
    _talk.initTalk();
    _game.initWorld("");//TODO 应该是输入有效的地图文件
    QCursor *myCursor=new QCursor(QPixmap("C:\\Users\\67549\\Desktop\\5690530967350055f\\more\\cursor.png"),-1,-1);
    this->setCursor(*myCursor);
    j=1;
    plot=0;
    k=1;

    pixmap = new QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\map1.jpg");

  /*  music1 = new QMediaPlayer();
    music2 = new QMediaPlayer();
    music1->setMedia(QUrl::fromLocalFile("C:\\Users\\67549\\Desktop\\Qt.map\\hope.mp3"));
    music2->setMedia(QUrl::fromLocalFile("C:\\Users\\67549\\Desktop\\Qt.map\\fight.mp3"));*/


    playlist=new QMediaPlaylist;
    playlist->setPlaybackMode(QMediaPlaylist::Loop);
  //  playlist->setCurrentInx(3);
    playlist->addMedia(QMediaContent(QUrl::fromLocalFile("C:\\Users\\67549\\Desktop\\Qt.map\\gamemusic.mp3")));
    playlist->addMedia(QMediaContent(QUrl::fromLocalFile("C:\\Users\\67549\\Desktop\\Qt.map\\fight.mp3")));
    player=new QMediaPlayer;
    player->setPlaylist(playlist);
    player->setVolume(88);
    player->play();

    soundbutton = new MyPushbutton(this);
    soundbutton->setGeometry(900,250,200,100);
    soundbutton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    soundbutton->setText("声音开关");
    soundbutton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(soundbutton,SIGNAL(clicked()),this,SLOT(sound()));
    soundbutton->setVisible(false);


    equipbutton = new MyPushbutton(this);
    equipbutton->setGeometry(0,700,100,50);
    equipbutton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    equipbutton->setText("装备");
    equipbutton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(equipbutton,SIGNAL(clicked()),this,SLOT(equipment()));


    startbutton = new MyPushbutton(this);
    startbutton->setGeometry(900,300,200,100);
    startbutton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    startbutton->setText("开始游戏");
    startbutton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(startbutton,SIGNAL(clicked()),this,SLOT(startgame()));

    continuebutton = new MyPushbutton(this);
    continuebutton->setGeometry(900,450,200,100);
    continuebutton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    continuebutton->setText("继续游戏");
    continuebutton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(continuebutton,SIGNAL(clicked()),this,SLOT(continuegame()));

    quitbutton = new MyPushbutton(this);
    quitbutton->setGeometry(900,600,200,100);
    quitbutton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    quitbutton->setText("结束游戏");
    quitbutton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(quitbutton,SIGNAL(clicked()),this,SLOT(quitgame()));

    backButton = new MyPushbutton(this);
    backButton->setGeometry(1400,800,100,50);
    backButton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    backButton->setText("返回");
    backButton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(backButton,SIGNAL(clicked()),this,SLOT(back()));

    savebutton= new MyPushbutton(this);
    savebutton->setGeometry(900,400,200,100);
    savebutton->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    savebutton->setText("保存游戏");
    savebutton->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(savebutton,SIGNAL(clicked()),this,SLOT(savegame()));
    savebutton->setVisible(false);

    BACK= new MyPushbutton(this);
    BACK->setGeometry(900,550,200,100);
    BACK->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    BACK->setText("回主界面");
    BACK->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(BACK,SIGNAL(clicked()),this,SLOT(back()));
    BACK->setVisible(false);

    jindu1= new MyPushbutton(this);
    jindu1->setGeometry(900,300,200,100);
    jindu1->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    jindu1->setText("进度一");
    jindu1->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(jindu1,SIGNAL(clicked()),this,SLOT(read1()));

    //jindu2= new QPushButton(this);
    jindu2= new MyPushbutton(this);
    jindu2->setGeometry(900,450,200,100);
    jindu2->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    jindu2->setText("进度二");
    jindu2->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(jindu2,SIGNAL(clicked()),this,SLOT(read2()));

    //jindu3= new QPushButton(this);
    jindu3= new MyPushbutton(this);
    jindu3->setGeometry(900,600,200,100);
    jindu3->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    jindu3->setText("进度三");
    jindu3->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(jindu3,SIGNAL(clicked()),this,SLOT(read3()));


    sjindu1= new MyPushbutton(this);
    sjindu1->setGeometry(900,300,200,100);
    sjindu1->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    sjindu1->setText("进度一");
    sjindu1->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(sjindu1,SIGNAL(clicked()),this,SLOT(save1()));

    sjindu2= new MyPushbutton(this);
    sjindu2->setGeometry(900,450,200,100);
    sjindu2->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
    sjindu2->setText("进度二");
    sjindu2->setFont(QFont("宋体",20,QFont::Bold));
    QObject::connect(sjindu2,SIGNAL(clicked()),this,SLOT(save2()));

                //jindu3= new QPushButton(this);
                sjindu3= new MyPushbutton(this);
                sjindu3->setGeometry(900,600,200,100);
                sjindu3->getIconPath("C:\\Users\\67549\\Desktop\\Qt.map\\kuang.png");
                sjindu3->setText("进度三");
                sjindu3->setFont(QFont("宋体",20,QFont::Bold));
                QObject::connect(sjindu3,SIGNAL(clicked()),this,SLOT(save3()));

                sjindu1->setVisible(false);
                sjindu2->setVisible(false);
                sjindu3->setVisible(false);
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *)
{
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    if(j==1)
    {
        equipbutton->setVisible(false);
        startbutton->setVisible(true);
                continuebutton->setVisible(true);
                quitbutton->setVisible(true);
                backButton->setVisible(false);
                BACK->setVisible(false);
                savebutton->setVisible(false);
                soundbutton->setVisible(false);
                jindu1->setVisible(false);
                jindu2->setVisible(false);
                jindu3->setVisible(false);
        sjindu1->setVisible(false);
        sjindu2->setVisible(false);
        sjindu3->setVisible(false);
        pa->drawPixmap(rect(),QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\jiemian1.jpg"));
        _talk.show(pa);
    }
    else if(j==2)
    {
      //  music1->play();
        equipbutton->setVisible(true);
        startbutton->setVisible(false);
        continuebutton->setVisible(false);
        quitbutton->setVisible(false);
        backButton->setVisible(false);
        jindu1->setVisible(false);
        jindu2->setVisible(false);
        jindu3->setVisible(false);






       // this->_game.showback(pa);

        pa->drawPixmap(rect(),*pixmap);
   //     pa->drawImage(QRect(30*32,11*32,230,110),QImage("C:/Users/67549/Desktop/Qt.map/npctalk/npc1-3.png"),QRect(0,0,230,110));
        this->_game.show(pa);
        this->_talk.show(pa);

    }
    else if(j==3)
    {
        equipbutton->setVisible(true);
        jindu1->setVisible(false);
        jindu2->setVisible(false);
        jindu3->setVisible(false);

        bool m1 = dlg->getenemy1();
        this->_game.changeenemy11(m1);
        if(m1==false)
        {
            plot=3;
        }
        bool m2 = dlg->getenemy2();
        this->_game.changeenemy22(m2);
        if(m2==false)
        {
            plot=7;
        }
        bool m3 = dlg->getenemy3();
        this->_game.changeenemy33(m3);
        if(m3==false)
        {
            plot=9;
        }
        pa->drawPixmap(rect(),QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\map2.png"));
        this->_game.showfight(pa);
    }
    else if(j==4)//继续游戏
    {
        jindu1->setVisible(true);
        jindu2->setVisible(true);
        jindu3->setVisible(true);
        sjindu1->setVisible(false);
        sjindu2->setVisible(false);
        sjindu3->setVisible(false);
        backButton->setVisible(true);
        startbutton->setVisible(false);
        continuebutton->setVisible(false);
        quitbutton->setVisible(false);
        pa->drawPixmap(rect(),QPixmap ("C:\\Users\\67549\\Desktop\\Qt.map\\cundang.jpg"));

    }
/*    if(i==1)
    {
        pa->drawImage(QRect (100,200,38,89),QImage ("C:\\Users\\67549\\Desktop\\5690530967350055f\\NPC_1\\03\\image 1.png"),QRect (0,0,38,89));
        i=2;
    }
    if(i==2)
    {
        pa->drawImage(QRect (100,200,38,202),QImage ("C:\\Users\\67549\\Desktop\\5690530967350055f\\NPC_1\\03\\image 3.png"),QRect (0,0,38,89));
        i=3;
    }
    if(i==3)
    {
        pa->drawImage(QRect (100,200,38,215),QImage ("C:\\Users\\67549\\Desktop\\5690530967350055f\\NPC_1\\03\\image 5.png"),QRect (0,0,38,89));
        i=0;
    }*/
    pa->end();
    delete pa;

}


/*void MW1::mouseDoubleClickEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {             // 如果是鼠标左键按下
        if(windowState() != Qt::WindowFullScreen)
            // 如果现在不是全屏
            setWindowState(Qt::WindowFullScreen);
        // 将窗口设置为全屏
        else setWindowState(Qt::WindowNoState);
        // 否则恢复以前的大小
    }
}*/

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game._player.changedirect(3);
        this->_game.handlePlayerMove1(3,16);

    }
    else if(e->key() == Qt::Key_D)
    {
        if(_game._player.getPosX()>54*32&&j==2)
        {
            _game._player.changei(-1);
            _game._player.setPosX(42*32);
            _game._player.setPosY(28*32);
            changej(3);
            playlist->next();
        }
        this->_game._player.changedirect(4);
        this->_game.handlePlayerMove1(4,16);

    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game._player.changedirect(1);
        this->_game.handlePlayerMove1(1,16);
    }
    else if(e->key() == Qt::Key_S)
    {
        if(_game._player.getPosY()>28*32+10&&j==3)
        {
            _game._player.changei(-1);
            _game._player.setPosX(54*32);
            _game._player.setPosY(20*32-10);
            changej(2);
        }
         this->_game._player.changedirect(2);
         this->_game.handlePlayerMove1(2,16);
          //      this->move();
    }
    else if(e->key()==Qt::Key_Escape)
    {
        if(k)
        {
        BACK->setVisible(true);
        savebutton->setVisible(true);
        soundbutton->setVisible(true);

        k=0;
        }
        else
        {
            BACK->setVisible(false);
            savebutton->setVisible(false);
            soundbutton->setVisible(false);

            k=1;
        }

    }
    this->repaint();
}

void MW1::mousePressEvent(QMouseEvent *e)
{
    if(j==2&&e->x()>=20*32&&e->x()<=24*32&&e->y()>=15*32&&e->y()<=19*32)
    {
        if(_game._player.getPosX()>19*32&&_game._player.getPosX()<22*32&&_game._player.getPosY()<19*32)
        {
            if(plot<5)
            {
                _talk.changek3(0);
                this->repaint();
            }

            else if(plot==5)
            {
                if(_talk.getk3()<7)
                {
                    int ii = _talk.getk3();
                    ii++;
                    _talk.changek3(ii);
                    this->repaint();
                }
                else if(_talk.getk3()==7)
                {
                    _talk.changek3(8);
                    this->repaint();
                    changeplot(6);
                }
            }
            else if(plot==7)
            {
                if(_talk.getk3()<13)
                {
                    int ii = _talk.getk3();
                    ii++;
                    _talk.changek3(ii);
                    this->repaint();
                }
                else if(_talk.getk3()==13)
                {
                    _talk.changek3(14);
                    this->repaint();
                    changeplot(8);
                }
            }
            else if(plot==9)
            {
                if(_talk.getk3()<16)
                {
                    int ii = _talk.getk3();
                    ii++;
                    _talk.changek3(ii);
                    this->repaint();
                }
                else if(_talk.getk3()==16)
                {
                    _talk.changek3(17);
                    this->repaint();
                    changeplot(10);
                }
            }
        }
    }
    else if(j==2&&e->x()>=30*32&&e->x()<=34*32&&e->y()>=15*32&&e->y()<=19*32)
    {
        if(_game._player.getPosX()>29*32&&_game._player.getPosX()<32*32&&_game._player.getPosY()<19*32)
        {
            if(plot==0)
            {
                if(_talk.getk2()<7)
                {
                    int ii = _talk.getk2();
                    ii++;
                    _talk.changek2(ii);
                    this->repaint();
                }
                else if(_talk.getk2()==7)
                {
                    _talk.changek2(8);
                    this->repaint();
                    changeplot(1);
                }
            }
            else if(plot==4)
            {
                if(_talk.getk2()<12)
                {
                    int ii = _talk.getk2();
                    ii++;
                    _talk.changek2(ii);
                    this->repaint();
                }
                else if(_talk.getk2()==12)
                {
                    _talk.changek2(13);
                    this->repaint();
                    changeplot(5);
                }
            }


        }
    }
    else if(j==2&&e->x()>=40*32&&e->x()<=44*32&&e->y()>=15*32&&e->y()<=19*32)
    {
        if(_game._player.getPosX()>39*32&&_game._player.getPosX()<42*32&&_game._player.getPosY()<19*32)
        {
            if(plot==0)
            {
                _talk.changek1(0);
                this->repaint();
            }
            else if(plot==1)
            {
                if(_talk.getk1()<4)
                {
                    int ii = _talk.getk1();
                    ii++;
                    _talk.changek1(ii);
                    this->repaint();
                }
                else if(_talk.getk1()==4)
                {
                    _talk.changek1(5);
                    this->repaint();
                    changeplot(2);
                }
            }
            else if(plot==3)
            {
                if(_talk.getk1()<7)
                {
                    int ii = _talk.getk1();
                    ii++;
                    _talk.changek1(ii);
                    this->repaint();
                }
                else if(_talk.getk1()==7)
                {
                    _talk.changek1(8);
                    this->repaint();
                    changeplot(4);

                }
            }
        }
    }
    else if(j==3&&e->x()>=37*32&&e->x()<=41*32&&e->y()>=11*32&&e->y()<=14*32)
    {
        if(fabs(_game._player.getPosX()-39*32)<=4*32&&fabs(_game._player.getPosY()-12*32-16)<=6*32)
        {
            dlg->changedisplay(1);
            dlg->changewho(0);
            dlg->setGeometry(100,100,1700,800);
            dlg->show();
            dlg->skill1->setVisible(true);
            dlg->skill2->setVisible(true);
            dlg->skill3->setVisible(true);

        }

    }
    else if(j==3&&e->x()>=21*32&&e->x()<=24*32&&e->y()>=16*32&&e->y()<=20*32)
    {
        if(fabs(_game._player.getPosX()-23*32)<=4*32&&fabs(_game._player.getPosY()-17*32-16)<=6*32)
        {

            dlg->changedisplay(1);
            dlg->changewho(1);
            dlg->setGeometry(100,100,1700,800);
            dlg->show();
            dlg->skill1->setVisible(true);
            dlg->skill2->setVisible(true);
            dlg->skill3->setVisible(true);

        }

    }
    else if(j==3&&e->x()>=14*32&&e->x()<=24*32&&e->y()>=0&&e->y()<=10*32)
    {
        if(fabs(_game._player.getPosX()-18*32)<=5*32&&fabs(_game._player.getPosY())<=12*32)
        {
            dlg->changedisplay(1);
            dlg->changewho(2);
            dlg->setGeometry(100,100,1700,800);
            dlg->show();
            dlg->skill1->setVisible(true);
            dlg->skill2->setVisible(true);
            dlg->skill3->setVisible(true);

        }

    }
}



/*void MW1::on_pushButton_clicked()
{
    changej(2);
    this->repaint();
}

void MW1::on_pushButton_3_clicked()
{
    close();
}*/


/*void MW1::mousePressEvent(QMouseEvent *e)
{
    if(e->button() == Qt::RightButton)
    {
        zou++;
        ui->label->setText(tr("(%1)").arg(zou));
        int a=zou;
        _game._player.setx(e->x());
        _game._player.sety(e->y());
        int k;
        dx=_game._player.getx()-_game._player.getPosX();
        dy=_game._player.gety()-_game._player.getPosY();
        if(dx>0)
        {
            for(k=0;;k++)
            {
                if(a==zou)
                {
                    this->_game._player.changedirect(4);
                    this->_game.handlePlayerMove1(4,16);
                    dx-=16;
                    if(dx<=8)
                    {
                        break;
                    }
                    this->repaint();
                }
                else
                    break;

            }

        }

    }
}*/

void MW1::equipment()
{
    dlg->changedisplay(0);
    dlg->setGeometry(200,100,800,600);
    dlg->show();

}

void MW1::back()
{
    changej(1);
    this->repaint();
}
void MW1::read1()
{

    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu1.txt");
    int i;
    file1>>i;
    if(i==0)
    {
        changej(2);
        this->repaint();
    }
    else if(i==4)
    {

        changej(2);
        plot=i;
        _talk.changek2(8);
        this->repaint();
    }
    else if(i==7)
    {
        changej(2);
        plot=i;
        _talk.changek3(8);
        this->repaint();

    }
    file1.close();

}
void MW1::read2()
{

    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu2.txt");
    int i;
    file1>>i;
    if(i==0)
    {
        changej(2);
        this->repaint();
    }
    else if(i==4)
    {

        changej(2);
        plot=i;
        _talk.changek2(8);
        this->repaint();
    }
    else if(i==7)
    {
        changej(2);
        plot=i;
        _talk.changek3(8);
        this->repaint();

    }
    file1.close();

}
void MW1::read3()
{

    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu3.txt");
    int i;
    file1>>i;
    if(i==0)
    {
        changej(2);
        this->repaint();
    }
    else if(i==4)
    {

        changej(2);
        plot=i;
        _talk.changek2(8);
        this->repaint();
    }
    else if(i==7)
    {
        changej(2);
        plot=i;
        _talk.changek3(8);
        this->repaint();

    }
    file1.close();

}
void MW1::startgame()
{
    changej(2);
    plot=0;
    this->repaint();
}
void MW1::continuegame()
{
    changej(4);
    this->repaint();
}
void MW1::quitgame()
{
    close();
}
void MW1::savegame()
{

    sjindu1->setVisible(true);
    sjindu2->setVisible(true);
    sjindu3->setVisible(true);
    soundbutton->setVisible(false);
    BACK->setVisible(false);
    savebutton->setVisible(false);
    /*fstream file2("C:\\Users\\67549\\Desktop\\Qt.map\\jindu1.txt",ios::ate|ios::out);
    file2.close();
    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu1.txt");
    int i;
    i=getplot();
    if(i<4)
    {
        i=0;
    }
    else if(i>=4&&i<7)
    {
        i=4;
    }
    else if(i>=7)
    {
        i=7;
    }
    file1<<i;*/
}
void MW1::save1()
{
    fstream file2("C:\\Users\\67549\\Desktop\\Qt.map\\jindu1.txt",ios::ate|ios::out);
    file2.close();
    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu1.txt");
    int i=plot;
    if(i<4)
        i=0;
    else if(i>3&&i<7)
        i=4;
    else
        i=7;
    file1<<i;
    sjindu1->setVisible(false);
    sjindu2->setVisible(false);
    sjindu3->setVisible(false);
}
void MW1::save2()
{
    fstream file2("C:\\Users\\67549\\Desktop\\Qt.map\\jindu2.txt",ios::ate|ios::out);
    file2.close();
    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu2.txt");
    int i=plot;
    if(i<4)
        i=0;
    else if(i>3&&i<7)
        i=4;
    else
        i=7;
    file1<<i;
    sjindu1->setVisible(false);
    sjindu2->setVisible(false);
    sjindu3->setVisible(false);
}
void MW1::save3()
{
    fstream file2("C:\\Users\\67549\\Desktop\\Qt.map\\jindu3.txt",ios::ate|ios::out);
    file2.close();
    fstream file1("C:\\Users\\67549\\Desktop\\Qt.map\\jindu3.txt");
    int i=plot;
    if(i<4)
        i=0;
    else if(i>3&&i<7)
        i=4;
    else
        i=7;
    file1<<i;
    sjindu1->setVisible(false);
    sjindu2->setVisible(false);
    sjindu3->setVisible(false);
}

void MW1::sound()
{
    if(k)
    {
        player->pause();
        k=0;
    }
    else
    {
        player->play();
        k=1;
    }
}

