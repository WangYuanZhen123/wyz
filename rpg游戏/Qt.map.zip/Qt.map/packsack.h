#ifndef PACKSACK_H
#define PACKSACK_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include "equipment.h"
//#include "dialog.h"
//using namespace std;
//class Dialog;

class Equipment;

class Packsack
{
public:
    Packsack():equip1(),equip2(),equip3()
    {
        equip1.setEquipment("Basic_equipment");
        equip2.setEquipment("Attract_equipment");
        equip3.setEquipment("Protective_equipment");
        Flag=1;
    }
    ~Packsack()
    {
        equip1.~Equipment();
        equip2.~Equipment();
        equip3.~Equipment();
    }

    void initPacksack();

    //void showback(QPainter *painter);
    void show(QPainter *painter);

    int get_x(){return _equip.getPosX();}
    int get_y(){return _equip.getPosY();}

    void setFlag(int flag){Flag=flag;}
    int getFlag(){return Flag;}

    int getProperty(int num, QString str);

private:
     vector<RPGObj> _objs;
     Equipment _equip;
     Equipment equip1,equip2,equip3;
     //QImage image01,image02,image03;
     int Flag;      //哪个装备
};

#endif // PACKSACK_H
