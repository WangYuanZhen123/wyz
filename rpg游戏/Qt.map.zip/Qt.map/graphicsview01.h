#ifndef GRAPHICSVIEW01_H
#define GRAPHICSVIEW01_H


class graphicsview01
{
public:
    graphicsview01();
};

#endif // GRAPHICSVIEW01_H
