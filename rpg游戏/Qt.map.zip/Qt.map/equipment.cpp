#include "equipment.h"
#include "rpgobj.h"

Equipment::Equipment()
{
    Name="Basic";               //装备名称
    Lethality=100;              //攻击力
    Defense=100;                //防御力
}

Equipment::~Equipment()
{
    Name="Basic";               //装备名称
    Lethality=100;              //攻击力
    Defense=100;                //防御力
}

void Equipment::setEquipment(QString name)
{
    if(name.startsWith("Basic")){
        Name=name;
        Lethality=100;
        Defense=100;
    }
    else if(name.startsWith("Attack")){
        Name=name;
        Lethality=1000;
        Defense=100;
    }
    else if(name.startsWith("Protective")){
        Name=name;
        Lethality=100;
        Defense=1000;
    }
}

void Equipment::setData(int level)
{
    for(int i=0;i<=level;i++)
    {
        Lethality=Lethality*i*0.01; //攻击i%加成
        Defense=Defense*i*0.005; //防御0.5i%加成
    }
}

int Equipment::getData(QString DataType)
{
    if(DataType.startsWith("Lethality")){
        return Lethality;
    }
    else if(DataType.startsWith("Defense")){
        return Defense;
    }
}

