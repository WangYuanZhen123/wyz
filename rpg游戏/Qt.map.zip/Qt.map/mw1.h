#ifndef MW1_H
#define MW1_H
#include "dialog.h"
#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include <QKeyEvent>
#include "rpgobj.h"
#include "world.h"
#include <QTime>
#include <QTimer>
#include "talk.h"
#include "mypushbutton.h"
#include <QMediaPlayer>
#include <QMediaPlaylist>
//#include <QUrl>

namespace Ui {
class MW1;
}

class MW1 : public QMainWindow
{
    Q_OBJECT

public:
    QMediaPlayer *player;
    QMediaPlaylist* playlist;
    MyPushbutton* equipbutton;
    MyPushbutton* startbutton;
    MyPushbutton* continuebutton;
    MyPushbutton* quitbutton;
    MyPushbutton* backButton;
    MyPushbutton* jindu1;
    MyPushbutton* jindu2;
    MyPushbutton* jindu3;
    MyPushbutton* savebutton;
    MyPushbutton* BACK;
    MyPushbutton *soundbutton;
    MyPushbutton* sjindu1;
    MyPushbutton* sjindu2;
    MyPushbutton* sjindu3;
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *);
  //  void mouseDoubleClickEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *e);
    void move();
    void changej(int m){j=m;}
    int getj(){return j;}
    void changeplot(int m){plot=m;}
    int getplot(){return plot;}

public slots:
    void back();
    void read1();
    void read2();
    void read3();
    void startgame();
    void continuegame();
    void quitgame();
    void savegame();
    void save1();
    void save2();
    void save3();
    void sound();
    void equipment();
protected slots:
   // void randomMove();//响应时钟事件的函数



private:
    Ui::MW1 *ui;
    World _game;
    int j;  //界面与游戏切换
    int k;//esc键
    Dialog *dlg;
    QPixmap *pixmap;
    Talk _talk;  //npc对话框
    int plot;  //故事情节
 //   QMediaPlayer *music1, *music2;

};

#endif // MW1_H
