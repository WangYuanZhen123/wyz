#include "mw2.h"

MW2::MW2()
{

}

