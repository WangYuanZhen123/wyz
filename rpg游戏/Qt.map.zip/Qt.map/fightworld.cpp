#include "fightworld.h"

Fightworld::Fightworld()
{

}

void Fightworld::initWorld()
{
    this->actor1.initObj("fightactor1");
    this->actor1.setPosX(300);
    this->actor1.setPosY(500);
    this->actor1.changeblood(1000);

    this->evil1.initObj("fightevil1");
    this->evil1.setPosX(1100);
    this->evil1.setPosY(500);

    this->evil21.initObj("fightevil1");
    this->evil21.setPosX(1200);
    this->evil21.setPosY(400);

    this->evil22.initObj("fightevil1");
    this->evil22.setPosX(1200);
    this->evil22.setPosY(600);

    this->evil14.initObj("fightevil4");
    this->evil14.setPosX(1200);
    this->evil14.setPosY(400);
    this->evil14.changeblood(500);
    this->evil14.changeattract(50);
    this->evil14.changedefence(50);

    this->evil15.initObj("fightevil4");
    this->evil15.setPosX(1200);
    this->evil15.setPosY(600);
    this->evil15.changeblood(500);
    this->evil15.changeattract(50);
    this->evil15.changedefence(50);

    this->evil2.initObj("fightevil2");
    this->evil2.setPosX(1100);
    this->evil2.setPosY(500);
    this->evil2.changeblood(2000);
    this->evil2.changeattract(150);
    this->evil2.changedefence(150);


    this->evil3.initObj("fightevil3");
    this->evil3.setPosX(1100);
    this->evil3.setPosY(320);
    this->evil3.changeblood(4000);
    this->evil3.changeattract(250);
    this->evil3.changedefence(250);


    die.load("C:\\Users\\67549\\Desktop\\Qt.map\\grave.png");
}

void Fightworld::show1(QPainter *painter)
{
    if(actor1.getlive() == true)
        this->actor1.show(painter);
    else
        painter->drawImage(360,500,die);   //角色死亡图片

    if(evil1.getlive() == true)
        this->evil1.show(painter);
    else
        painter->drawImage(1160,500,die);
    if(evil14.getlive() == true)
        this->evil14.show(painter);
    else
        painter->drawImage(1260,400,die);
    if(evil15.getlive() == true)
        this->evil15.show(painter);
    else
        painter->drawImage(1260,600,die);
}
void Fightworld::show2(QPainter *painter)
{
    if(actor1.getlive() == true)
        this->actor1.show(painter);
    else
        painter->drawImage(360,500,die);

    if(evil2.getlive() == true)
        this->evil2.show(painter);
    else
        painter->drawImage(1160,500,die);
    if(evil21.getlive() == true)
        this->evil21.show(painter);
    else
        painter->drawImage(1260,400,die);
    if(evil22.getlive() == true)
        this->evil22.show(painter);
    else
        painter->drawImage(1260,600,die);
}
void Fightworld::show3(QPainter *painter)
{
    if(actor1.getlive() == true)
        this->actor1.show(painter);
    else
        painter->drawImage(360,500,die);

    if(evil3.getlive() == true)
        this->evil3.show(painter);
    else
        painter->drawImage(1160,500,die);

}
