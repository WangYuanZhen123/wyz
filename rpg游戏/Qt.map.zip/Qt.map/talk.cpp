#include "talk.h"

void Talk::initTalk()
{
    k1=0;
    k2=0;
    k3=0;
    npc1_1.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc1-1.png");
    npc1_2.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc1-2.png");
    npc1_3.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc1-3.png");
    npc1_4.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc1-4.png");
    npc1_5.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc1-5.png");
    npc1_6.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc1-6.png");
    npc2_1.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-1.png");
    npc2_2.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-2.png");
    npc2_3.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-3.png");
    npc2_4.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-4.png");
    npc2_5.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-5.png");
    npc2_6.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-6.png");
    npc2_7.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-7.png");
    npc2_8.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-8.png");
    npc2_9.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-9.png");
    npc2_10.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-10.png");
    npc2_11.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc2-11.png");
    npc3_1.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-1.png");
    npc3_2.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-2.png");
    npc3_3.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-3.png");
    npc3_4.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-4.png");
    npc3_5.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-5.png");
    npc3_6.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-6.png");
    npc3_7.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-7.png");
    npc3_8.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-8.png");
    npc3_9.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-9.png");
    npc3_10.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-10.png");
    npc3_11.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-11.png");
    npc3_12.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-12.png");
    npc3_13.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-13.png");
    npc3_14.load("C:\\Users\\67549\\Desktop\\Qt.map\\npctalk\\npc3-14.png");

}

void Talk::show(QPainter *painter)
{
    if(k1==1)
    {
        painter->drawImage(40*32,11*32,npc1_1);
    }
    else if(k1==2)
    {
        painter->drawImage(40*32,11*32,npc1_2);
    }
    else if(k1==3)
    {
        painter->drawImage(40*32,11*32,npc1_3);
    }
    else if(k1==4)
    {
        painter->drawImage(40*32,11*32,npc1_4);
    }
    else if(k1==6)
    {
        painter->drawImage(40*32,11*32,npc1_5);
    }
    else if(k1==7)
    {
        painter->drawImage(40*32,11*32,npc1_6);
    }
    if(k2==1)
    {
        painter->drawImage(30*32+15,11*32,npc2_1);
    }
    else if(k2==2)
    {
        painter->drawImage(30*32+15,11*32,npc2_2);
    }
    else if(k2==3)
    {
        painter->drawImage(30*32+15,11*32,npc2_3);
    }
    else if(k2==4)
    {
        painter->drawImage(30*32+15,11*32,npc2_4);
    }
    else if(k2==5)
    {
        painter->drawImage(30*32+15,11*32,npc2_5);
    }
    else if(k2==6)
    {
        painter->drawImage(30*32+15,11*32,npc2_6);
    }
    else if(k2==7)
    {
        painter->drawImage(30*32+15,11*32,npc2_7);
    }
    else if(k2==9)
    {
        painter->drawImage(30*32+15,11*32,npc2_8);
    }
    else if(k2==10)
    {
        painter->drawImage(30*32+15,11*32,npc2_9);
    }
    else if(k2==11)
    {
        painter->drawImage(30*32+15,11*32,npc2_10);
    }
    else if(k2==12)
    {
        painter->drawImage(30*32+15,11*32,npc2_11);
    }
    if(k3==1)
    {
        painter->drawImage(20*32+15,11*32,npc3_1);
    }
    else if(k3==2)
    {
        painter->drawImage(20*32+15,11*32,npc3_2);
    }
    else if(k3==3)
    {
        painter->drawImage(21*32,11*32,npc3_3);
    }
    else if(k3==4)
    {
        painter->drawImage(21*32,11*32,npc3_4);
    }
    else if(k3==5)
    {
        painter->drawImage(21*32,11*32,npc3_5);
    }
    else if(k3==6)
    {
        painter->drawImage(21*32,11*32,npc3_6);
    }
    else if(k3==7)
    {
        painter->drawImage(21*32,11*32,npc3_7);
    }
    else if(k3==9)
    {
        painter->drawImage(21*32,11*32,npc3_8);
    }
    else if(k3==10)
    {
        painter->drawImage(21*32,11*32,npc3_9);
    }
    else if(k3==11)
    {
        painter->drawImage(21*32,11*32,npc3_10);
    }
    else if(k3==12)
    {
        painter->drawImage(21*32,11*32,npc3_11);
    }
    else if(k3==13)
    {
        painter->drawImage(21*32,11*32,npc3_12);
    }
    else if(k3==15)
    {
        painter->drawImage(21*32,11*32,npc3_13);
    }
    else if(k3==16)
    {
        painter->drawImage(21*32,11*32,npc3_14);
    }




}

