#ifndef FIGHTWORLD_H
#define FIGHTWORLD_H
#include "fightactor.h"


class Fightworld: public Fightactor
{
    friend class Dialog;
public:
    Fightworld();
    ~Fightworld(){}
    void initWorld();
    void show1(QPainter *painter);
    void show2(QPainter *painter);
    void show3(QPainter *painter);

private:
    Fightactor evil1, evil14, evil15, evil2, evil3, evil21,evil22;   //敌人
    Fightactor actor1,actor2;       //玩家
    QImage die;     //死亡图片
};

#endif // FIGHTWORLD_H
