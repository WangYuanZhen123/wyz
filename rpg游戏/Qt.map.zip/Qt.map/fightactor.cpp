#include "fightactor.h"

Fightactor::Fightactor()
{
    blood=1000;
    attract = 100;
    defence = 100;
    live = true;
}

