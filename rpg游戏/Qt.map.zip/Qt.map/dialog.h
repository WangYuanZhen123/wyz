#ifndef DIALOG_H
#define DIALOG_H
#include<QDialog>
#include "packsack.h"
#include "fightworld.h"
#include "mypushbutton.h"

namespace Ui {
class Dialog;
class Packsack;
}

class Dialog : public QDialog
{
    Q_OBJECT
public:
    explicit Dialog(QWidget *parent=0);
    ~Dialog();
   void paintEvent(QPaintEvent *);

   MyPushbutton* skill1;
   MyPushbutton* skill2;
   MyPushbutton* skill3;

   void set_Flag(int newnum){_bag.setFlag(newnum);}
   int get_Flag(){return _bag.getFlag();}

   void changedisplay(int m){display = m;}
   int getdisplay(){return display;}
   void changewho(int m){who=m;}
   int getwho(){return who;}
   bool getenemy1(){return enemy1;}
   bool getenemy2(){return enemy2;}
   bool getenemy3(){return enemy3;}

   void getNewEquipment(){got++;}
   void setLabel();
   void setPicture();

public slots:
   void skill10();
   void skill20();
   void skill30();

private slots:
   void on_pushButton_clicked();

   void on_pushButton_2_clicked();


   void stop11();
   void stop22();
   void fanji();


private:
   Ui::Dialog *ui;
   //int Flag;
   int display;  //装备界面还是战斗界面
   int who;      //是哪个怪物
   QMovie *movie0, *movie11, *movie12, *movie13, *movie21, *movie31, *movie51, *movie52;    //技能动图
   QMovie *movie110, *movie120, *movie130, *movie210, *movie310, *movie510, *movie520;
   QTimer *time, *time11, *time22;      //动图播放时间
   Packsack _bag;
   Fightworld fightworld;       //战斗界面
   QImage blood0, blood1;       //血条图片
   QImage victory, lose;        //胜负图片
   bool enemy1, enemy2, enemy3;     //敌人是否存活
  // QImage evil1, evil2, evil3;
   int skill, skill0;       //判断放的是哪个技能
   int got;//记录装备件数

};

#endif // MYQDIALOG_H
