#ifndef EQUIPMENT_H
#define EQUIPMENT_H
#include <QString>
#include "rpgobj.h"


class Equipment :public RPGObj
{
public:
    Equipment();
    ~Equipment();
    void setEquipment(QString name);

    void setData(int level);//用于修改装备属性
    int getData(QString DataType);//用于读取装备属性

    //void show(QPainter *painter);

private:
    QString Property;    //通用属性（装备简介）
    QString Name;        //名称
    int Lethality;       //攻击力
    int Defense;         //防御力

};

#endif // EQUIPMENT_H
