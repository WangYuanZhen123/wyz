#ifndef FIGHTACTOR_H
#define FIGHTACTOR_H
#include "rpgobj.h"

class Fightactor:public RPGObj
{
public:
    Fightactor();
    ~Fightactor(){}
    void changeblood(int m){blood = m;}
    int getblood(){return blood;}
    void changeattract(int m){attract = m;}
    int getattract(){return attract;}
    void changedefence(int m){defence = m;}
    int getdefence(){return defence;}
    void changelive(bool m){live = m;}
    bool getlive(){return live;}
private:
    int blood, attract, defence;        //人物属性
    bool live;      //判断人物是否存活
};

#endif // FIGHTACTOR_H
