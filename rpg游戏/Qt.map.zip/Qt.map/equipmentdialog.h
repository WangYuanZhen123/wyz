#ifndef EQUIPMENTDIALOG_H
#define EQUIPMENTDIALOG_H
#include <QMainWindow>
#include "packsack.h"

class equipmentDialog: public QDialog
{
    Q_OBJECT
public:
    explicit equipmentDialog(QWidget *parent = 0);
    ~equipmentDialog();
    void changeFlag(int newFlag) ;

protected:
    void paintEvent(QPaintEvent *);

private:
    Packsack _bag;

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

};

#endif // EQUIPMENTDIALOG_H


