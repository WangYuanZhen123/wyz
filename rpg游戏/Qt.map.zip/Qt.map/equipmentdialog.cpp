#include "equipmentDialog.h"
#include "ui_mw1.h"
#include "packsack.h"
#include <QPainter>
#include <iostream>
#include <QDialog>
equipmentDialog::equipmentDialog(QWidget *parent) :
    QDialog(parent)
{

}
equipmentDialog::~equipmentDialog()
{

}

void equipmentDialog::equipmentDialog(QPaintEvent *)
{

    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawPixmap(rect(), QPixmap("D:\\QT_work\\QT_assignment\\ShadowGame\\image.jpg"));
    this->_bag.show(pa);
    pa->end();
    delete pa;

}

void equipmentDialog::changeFlag(int newFlag)
{
    if(newFlag>=0&&newFlag<=3)
        _bag.setFlag(newFlag) ;
    else if(newFlag<0) _bag.setFlag(0) ;
    else if(newFlag>3) _bag.setFlag(3) ;
}

void equipmentDialog::on_pushButton_clicked()
{
    changeFlag(_bag.getFlag()-1);
    this->repaint();
}

void equipmentDialog::on_pushButton_2_clicked()
{
    changeFlag(_bag.getFlag()+1);
    this->repaint();
}
