#include "icon.h"
#include<iostream>
//int ICON::GRID_SIZE = 32;


pair<string,ICON> pairArray[] =
{
    make_pair("stone",ICON("stone",4*32,9*32, 1*32, 1*32)),

    make_pair("player",ICON("player",0,0, 77, 95)),
    make_pair("npc1",ICON("npc1",0,0,106,101)),
    make_pair("npc2",ICON("npc2",0,0,74,97)),
    make_pair("npc3",ICON("npc3",0,0,104,82)),
    make_pair("door",ICON("door",0,0,300,300)),
    make_pair("enemy1",ICON("enemy1",0,0,122,74)),
    make_pair("enemy2",ICON("enemy2",0,0,76,129)),
    make_pair("enemy3",ICON("enemy3",0,0,300,316)),
    make_pair("equip1",ICON("equip1",0,0,185,283)),
    make_pair("equip2",ICON("equip2",0,0,138,334)),
    make_pair("equip3",ICON("equip3",0,0,250,254)),
    make_pair("fightactor1",ICON("fightactor1",0,0,142,162)),
    make_pair("fightactor2",ICON("fightactor2",0,0,206,98)),
    make_pair("fightevil1",ICON("fightevil1",0,0,122,74)),
    make_pair("fightevil2",ICON("fightevil2",0,0,113,104)),
    make_pair("fightevil3",ICON("fightevil3",0,0,300,316)),
    make_pair("fightevil4",ICON("fightevil4",0,0,134,62)),


};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}
