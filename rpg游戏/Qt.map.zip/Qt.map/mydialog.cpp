#include "mydialog.h"
#include <QPainter>
#include "ui2_"

MyQDialog::MyQDialog(QWidget *parent) :
    QDialog(parent),
    ui2(new Ui::MyQDialog)
{
    ui2->setupUi(this);
}

MyQDialog::~MyQDialog()
{
    //delete ui2;
}

void MyQDialog::paintEvent(QPaintEvent *)
{
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawPixmap(rect(),QPixmap("C:\\Users\\67549\\Desktop\\Qt.map\\map3.jpg"));
    pa->end();
    delete pa;
}

