#ifndef TALK_H
#define TALK_H
#include "rpgobj.h"
#include <QPainter>
#include <string>

class Talk
{
public:
    Talk(int i=0, int j=0, int k=0):k1(i),k2(j),k3(k){}
    ~Talk(){}
    void changek1(int i){k1=i;}
    int getk1(){return k1;}
    void changek2(int i){k2=i;}
    int getk2(){return k2;}
    void changek3(int i){k3=i;}
    int getk3(){return k3;}
    void initTalk();
    void show(QPainter *painter);
private:
    int k1, k2, k3;   //k1是大叔，k2是塞利亚，k3是风振
    QImage npc1_1, npc1_2, npc1_3, npc1_4, npc1_5, npc1_6;
    QImage npc2_1, npc2_2, npc2_3, npc2_4, npc2_5, npc2_6, npc2_7, npc2_8, npc2_9, npc2_10, npc2_11;
    QImage npc3_1, npc3_2, npc3_3, npc3_4, npc3_5, npc3_6, npc3_7, npc3_8, npc3_9, npc3_10, npc3_11, npc3_12, npc3_13, npc3_14;
};

#endif // TALK_H
